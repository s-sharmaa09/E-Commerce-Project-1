<?php

session_start();
?>

<!DOCTYPE html>
<html>
<head>
	<title>Store</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="jumbotron">
        <h1 class="text-center display-4">Products List</h1>
        <center><a href="index.php" class="btn btn-warning">Home</a>
        <a href="store.php" class="btn btn-warning">Products</a></center>
    </div>
    <div class="container">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "BookStoreCreator");
        $sql = mysqli_query($conn, "SELECT * FROM insertinventory");

        $id = 'ID';
        $name = 'product_name';
        $desc = 'prod_desc';
        $price = 'price';
        $quantity = 'quantity';
        $image = 'image';

        $form = "";

        if(mysqli_num_rows($sql) > 0) {

            while($row = mysqli_fetch_array($sql)) {
                $id = $row['ID'];
                $name = $row['product_name'];
                $desc = $row['prod_desc'];
                $quantity = $row['quantity'];
                $price = $row['price'];
                $image = $row['image'];

                $form .= "<div>
												<div style='text-align:center;'>
													<u><em><h4>$name</h4></em></u><br>
												</div>
												<div style='text-align:center;'>
													<img src=$image class='Img' style='height:30%; width:25%'>
												</div><br>
												<div style='text-align:center;'>
													<p>$desc</p>
												</div><br>
												<div style='text-align:center;'>
													<p>Remaining Stock: $quantity</p>
												</div><br>
												<div style='text-align:center;'>
													<p>Price: $$price</p><br>
												</div>
												<div style='text-align:center;'>
													<a class='btn btn-primary btn-lg' href='confirmation.php?pid=$id'>Buy</a>
												</div><br>
											</div>
											<hr>";
            }
            echo $form;
        }
        ?>
    </div>
    <footer>
			<center>Copyright &copy; The Book Store 2021</center>
		</footer>
</body>
</html>