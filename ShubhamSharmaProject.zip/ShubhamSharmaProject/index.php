<!DOCTYPE html>
<html>
<head>
	<title>The Book Store</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <link rel="stylesheet" type="text/css" href="./styles/style.css">
</head>
<body  style="background-color:#f4f9f9">
    <h1><i><center>The Book Store</center></i></h1>
    <center><h4>This Book Store was established by an Indian family back in 1990. This book store guarantee the best price around K-W area and even provide customers with the service of price match.
    The Book Store has been able to set a good customer satisfaction and focus on providing best deals to their customer.
        </h4></center>
	<div class="container text-center">
        <center><img src="images/main.jpg" height="500" width="600" class="img img-responsive"></center>
        <br>
		<a href="store.php" class="btn btn-warning">Explore our Book Store</a>
	</div>
    <br>
    <footer>
			<center>Copyright &copy; The Book Store 2021</center>
		</footer>
</body>
</html>