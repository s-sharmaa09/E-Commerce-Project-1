-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 20, 2019 at 03:43 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `BookStoreCreator`
--

-- --------------------------------------------------------

--
-- Table structure for table `insertinventory`
--

CREATE TABLE `insertinventory` (
  `ID` int(11) NOT NULL,
  `product_name` varchar(50) NOT NULL,
  `prod_desc` varchar(10000) NOT NULL,
  `price` int(10) NOT NULL,
  `quantity` int(200) NOT NULL,
  `image` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `insertinventory`
--

INSERT INTO `insertinventory` (`ID`, `product_name`, `prod_desc`, `price`, `quantity`, `image`) VALUES
(1, 'PHP 7.4', 'This updated edition teaches everything you need to know to create effective web applications using the latest features in PHP 7.4.', 54, 7, 'images/i1.jpg'),
(2, 'C++ For Beginners', 'Have you heard about C++ but have no idea where to start from?

Well, there’s no need to worry because the C++ For Beginners is here to teach you everything there is to know to get started on coding!', 12, 7, 'images/i2.jpg'),
(3, 'Professional C++', 'Professional C++, 5th Edition raises the bar for advanced programming manuals. Complete with a comprehensive overview of the new capabilities of C++20, each feature of the newly updated programming language is explained in detail and with examples', 56, 7, 'images/i3.jpg'),
(4, 'HTML And CSS', 'Need to learn HTML and CSS fast? This best-selling reference visual format and step-by-step, task-based instructions will have you up and running with HTML in no time.', 90, 7, 'images/i4.jpg'),
(5, 'JavaScript', 'Like it or not, JavaScript is everywhere these days—from browser to server to mobile—and now you, too, need to learn the language or dive deeper than you have. This concise book guides you into and through JavaScript, written by a veteran programmer who once found himself in the same position.', 45, 7, 'images/i5.jpg'),
(6, 'Python For Beginners', 'Python is a simple yet powerful programming language that can enable you to start thinking like a programmer right from the beginning. It is very readable and the stress many beginners face about memorizing arcane syntax typically presented by other programming languages will not affect you at all.', 15, 7, 'images/i6.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `ID` int(11) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `payment` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `firstname`, `lastname`, `address`, `payment`) VALUES
(6, 'Mrunal', 'S3', 'abc', 'Credit Card');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `insertinventory`
--
ALTER TABLE `insertinventory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `insertinventory`
--
ALTER TABLE `insertinventory`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
