
<!DOCTYPE html>
<html>
<head>
    <title>Confirmation</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
	<div class="success">
		<h1 style="font-size: 4em; text-align: center;">Hurray...Your Order Has Been Placed!</h1>
    	<p style="font-size: 2em; text-align: center;"><a href="index.php">Place New Order</a></p>
	</div>
</body>
</html>